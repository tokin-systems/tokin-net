defmodule Tokin do
    import Enum
    pid = spawn fn -> IO.puts 8*2 end
    Enum.map [1,2,3,5,8], fn x -> x * x end
    favor = IO.gets "yes or no?"
    for n <- [1,2,3,5,8,13,21,34,55,89,144], do: IO.puts(n * 4)
    IO.inspect {favor, pid}
end