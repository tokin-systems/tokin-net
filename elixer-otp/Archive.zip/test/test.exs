fire = fn a ->
dlist = [1, 2, 34, 5, 345593, 7, 885, 6, 3240] 
IO.puts [hello | _] = dlist 
end

fire.("The humble start to a global uncentralized distribution #{:tokin}")

